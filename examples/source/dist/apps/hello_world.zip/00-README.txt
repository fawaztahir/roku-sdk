/*
 * Copyright (c) 2015 Roku, Inc. All rights reserved.
 * This software and any compilation or derivative thereof is,
 * and shall remain, the proprietary information of Roku, Inc. and
 * is highly confidential in nature. Reproduction in whole or in part
 * is prohibited without the prior written consent of Roku, Inc.
 * 
 * Under no circumstance may this software or any derivative thereof be
 * combined with any third party software, including open source software,
 * without the written permission of the Copyright owner.
 */

This application is meant for use in public presentations. In the future,
it may be released publicly as example source code.



